using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ImageMagick;

namespace Lab4.Pages
{
    public class UploadModel : PageModel
    {
        [BindProperty]
        public IFormFile Upload { get; set; }

        private readonly string imagesDir;

        public UploadModel(IWebHostEnvironment environment)
        {
            imagesDir = Path.Combine(environment.WebRootPath, "images");
        }

        public IActionResult OnPost()
        {
            if (Upload == null)
            {
                ModelState.AddModelError("Upload", "Nie wybrano pliku.");
                return Page();
            }
            
            if (Upload.Length > 1 * 1024 * 1024)
            {
                ModelState.AddModelError("Upload", "Plik jest za duży (max. 1 MB)");
                return Page();
            }

            string extension = ".jpg";

            switch (Upload.ContentType)
            {
                case "image/png":
                    extension = ".png";
                    break;
                case "image/gif":
                    extension = ".gif";
                    break;
            }

            var fileName = Path.GetFileNameWithoutExtension(Path.GetRandomFileName()) + extension;
            var targetPath = Path.Combine(imagesDir, fileName);
            
            using (var image = new MagickImage(Upload.OpenReadStream()))
            using (var watermark = new MagickImage("znak.png"))
            {
                watermark.Evaluate(Channels.Alpha, EvaluateOperator.Divide, 4);
                image.Composite(watermark, Gravity.Southeast, CompositeOperator.Over);
                image.Write(targetPath);
            }

            return RedirectToPage("Index");
        }
    }
}