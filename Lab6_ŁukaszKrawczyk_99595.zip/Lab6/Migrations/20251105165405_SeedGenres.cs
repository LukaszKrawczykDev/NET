﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Lab6.Migrations
{
    /// <inheritdoc />
    public partial class SeedGenres : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                "Genres",
                new[] { "Id", "Name" },
                new object[,]
                {
                    { 3, "Drama" },
                    { 4, "Comedy" },
                    { 5, "Action" },
                    { 6, "Sci-Fi" },
                    { 7, "Fantasy" },
                    { 8, "Documentary" },
                    { 9, "Horror" }
                });
        }
        
        

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
