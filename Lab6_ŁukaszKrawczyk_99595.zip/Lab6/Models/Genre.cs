using System.ComponentModel.DataAnnotations;

namespace Lab6.Models
{
    public class Genre
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Pole 'Nazwa gatunku' jest wymagane.")]
        public string Name { get; set; }
    }
}