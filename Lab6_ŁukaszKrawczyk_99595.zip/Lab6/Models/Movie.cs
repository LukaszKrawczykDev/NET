using System.ComponentModel.DataAnnotations;

namespace Lab6.Models
{
    public class Movie
    {   [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Pole 'Tytuł' jest wymagane.")]
        [MaxLength(50, ErrorMessage = "Pole 'Tytuł' może zawierać maksymalnie 50 znaków.")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Pole 'Opis' jest wymagane.")]
        [UIHint("LongText")]
        public string Description { get; set; }
    
        [Required(ErrorMessage = "Pole 'Ocena' jest wymagane.")]
        [Range(1, 5, ErrorMessage = "Ocena filmu musi być liczbą pomiędzy 1 a 5.")]
        [UIHint("Stars")]
        public int Rating { get; set; }
        
        [Required(ErrorMessage = "Pole 'Gatunek' jest wymagane.")]
        public Genre Genre { get; set; }
        public string? TrailerLink { get; set; }
    }
}
