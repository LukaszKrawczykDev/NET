using System.ComponentModel.DataAnnotations;

namespace Lab5.Models
{
    public class Movie
    {
        [Key] 
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }
        
        [UIHint("LongText")]
        public string Description { get; set; }

        [Range(0, 5)]
        [UIHint("Stars")]
        public int Rating { get; set; }

        [Display(Name = "Trailer (YouTube link)")]
        public string TrailerLink { get; set; }
    }
}