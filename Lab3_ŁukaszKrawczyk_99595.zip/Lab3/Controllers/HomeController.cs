using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Lab3.Models;

namespace Lab3.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly FruitService _fruitService;

    public HomeController(ILogger<HomeController> logger, FruitService fruitService)
    {
        _logger = logger;
        _fruitService = fruitService;
    }
    
    public IActionResult Fruits([FromQuery] string? sort = "id", [FromQuery] string? dir = "asc")
    {
        var fruits = _fruitService.GetFruits();
        fruits = (sort, dir) switch
        {
            ("id", "desc") => fruits.OrderByDescending(f => f.Id),
            ("id", _) => fruits.OrderBy(f => f.Id),

            ("name", "desc") => fruits.OrderByDescending(f => f.Name),
            ("name", _) => fruits.OrderBy(f => f.Name),

            ("sweet", "desc") => fruits.OrderByDescending(f => f.IsSweet),
            ("sweet", _) => fruits.OrderBy(f => f.IsSweet),

            ("price", "desc") => fruits.OrderByDescending(f => f.Price),
            ("price", _) => fruits.OrderBy(f => f.Price),
            _ => fruits
        };
        
        ViewData["Sort"] = sort;
        ViewData["Dir"] = dir;

        return View(fruits);
    }
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(Fruit fruit)
    {
        if (ModelState.IsValid)
        {
            _fruitService.Add(fruit);
            return RedirectToAction("Fruits");
        }
        return View();
    }
    public IActionResult Delete(int id)
    {
        bool removed = _fruitService.Remove(id);
        if (!removed)
        {
            return NotFound();
        }
        return RedirectToAction("Fruits");
    }


    public IActionResult Index()
    {
        ViewData["random"] = Random.Shared.NextDouble();
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}