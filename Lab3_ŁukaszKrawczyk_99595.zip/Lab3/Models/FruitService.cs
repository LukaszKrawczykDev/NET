namespace Lab3.Models;

public class FruitService
{
    private List<Fruit> fruits;
    private int nextId = 1;

    public FruitService()
    {
        fruits = new List<Fruit>();
        for (int i = 0; i < 10; i++)
        {
            var fruit = Fruit.Create();
            fruit.Id = nextId++;
            fruits.Add(fruit);
        }
    }
    public void Add(Fruit fruit)
    {
        fruit.Id = fruits.Max(x => x.Id) + 1;
        fruits.Add(fruit);
    }
    public bool Remove(int id)
    {
        var fruitToRemove = fruits.FirstOrDefault(f => f.Id == id);
        if (fruitToRemove != null)
        {
            fruits.Remove(fruitToRemove);
            return true;
        }
        return false; 
    }

    public IEnumerable<Fruit> GetFruits()
    {
        return fruits;
    }
}
