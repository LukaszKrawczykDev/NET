using System.Globalization;

namespace Lab2;


public class Fruit 
{
    public string Name { get; set; }
    public bool IsSweet { get; set; }
    public double Price { get; set; }
    public double UsdPrice => Price / UsdCourse.Current;

    public static Fruit Create()
    {
        Random r = Random.Shared;
        string[] names =
        {
            "Apple",
            "Banana",
            "Cherry",
            "Durian",
            "Elderberry",
            "Grape",
            "Jackfruit",
        };

        return new Fruit
        {
            Name = names[r.Next(names.Length)],
            IsSweet = r.NextDouble() > 0.5,
            Price = Math.Round(r.NextDouble() * 10, 2) 
        };
    }
    
    public static string FormatUsdPrice(double price)
    {
        var usc = new CultureInfo("en-us");
        return price.ToString("C2", usc);
    }

    public override string ToString()
    {
        string plnPrice = Price.ToString("C2", new CultureInfo("pl-PL"));
        string usdPrice = FormatUsdPrice(UsdPrice);

        return $"Fruit: Name={Name}, IsSweet={IsSweet}, Price={plnPrice}, UsdPrice={usdPrice}";
    }
}