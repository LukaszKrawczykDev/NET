﻿using Lab2;
using System.Linq;

List<Fruit> fruits = new List<Fruit>();

for (int i = 0; i < 15; i++)
{
    fruits.Add(Fruit.Create());
}

UsdCourse.Current = await UsdCourse.GetUsdCourseAsync();
Console.WriteLine($"Aktualny kurs dolara: {UsdCourse.Current} PLN\n");

Console.WriteLine("Wszystkie owoce:");
foreach (Fruit fruit in fruits)
{
    Console.WriteLine(fruit);
}

var sweetFruits = fruits
    .Where(f => f.IsSweet)
    .OrderByDescending(f => f.Price);

Console.WriteLine("\nSłodkie owoce (posortowane malejąco po cenie):");
foreach (Fruit fruit in sweetFruits)
{
    Console.WriteLine(fruit);
}

