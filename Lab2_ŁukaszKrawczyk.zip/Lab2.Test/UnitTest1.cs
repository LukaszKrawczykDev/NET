using System.Globalization;

namespace Lab2.Test;
using Lab2;

public class UnitTest1
{
    [Fact]
    public void Fruit_ToString_ShouldReturnProperlyFormattedString()
    {
        UsdCourse.Current = 4.0f;
        var fruit = new Fruit
        {
            Name = "Apple",
            IsSweet = true,
            Price = 8.00
        };
        
        var result = fruit.ToString();
        
        string expected = $"Fruit: Name=Apple, IsSweet=True, Price={fruit.Price.ToString("C2", new CultureInfo("pl-PL"))}, UsdPrice={Fruit.FormatUsdPrice(fruit.UsdPrice)}";
        
        Assert.Equal(expected, result);
    }
    
    [Fact]
    public void Fruit_Create_ShouldGenerateMultipleDifferentNames()
    {
        var fruits = Enumerable.Range(0, 20)
            .Select(_ => Fruit.Create())
            .ToList();

        var distinctNames = fruits.Select(f => f.Name).Distinct().Count();
        Assert.True(distinctNames > 1, $"Expected more than one unique fruit name, but got only {distinctNames}.");
    }

}